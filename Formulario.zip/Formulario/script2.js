document.addEventListener("DOMContentLoaded", function () {
    const formulario = document.getElementById("formulario");
    const Errorid = document.getElementById("Errorid");
    const Errornombres = document.getElementById("Errornombres");
    const Errortel = document.getElementById("Errortel");
    const Errorcorreo = document.getElementById("Errorcorreo");
    const Erroredad = document.getElementById("Erroredad");
    const Errorfecha = document.getElementById("Errorfecha");
    const NoError = document.getElementById("NoError");
    var Errors=false;

    formulario.addEventListener("submit", function (event) {
        event.preventDefault();
        Errorid.textContent = "";
        Errornombres.textContent = "";
        Errortel.textContent = "";
        Errorcorreo.textContent = "";
        Erroredad.textContent = "";
        Errorfecha.textContent = "";
        NoError.textContent = "";

        // Obtener los valores de los campos
        const id = formulario.id.value;
        const nombre = formulario.nombre.value;
        const apellidos = formulario.apellidos.value;
        const telefono = formulario.telefono.value;
        const correo = formulario.correo.value;
        const edad = formulario.edad.value;
        const fechaNacimiento = formulario.fechaNacimiento.value;

        // Validar ID (5 dígitos exactos)
        if (!/^\d{5}$/.test(id)) {
            Errorid.textContent = "El ID debe tener 5 dígitos exactos.";
            var Errors = true;
        }


        // Validar nombre y apellidos (no pueden estar vacíos)
        if (nombre.trim() === "" || apellidos.trim() === "") {
            Errornombres.textContent = "El nombre y los apellidos no pueden estar vacíos.";
            var Errors = true;
        }


        // Validar teléfono (###)###-####
        if (!/^[(]{1}\d{3}[)]{1}\d{3}-\d{4}$/.test(telefono)) {
            Errortel.textContent += "El teléfono debe tener el formato ### ###-####.";
        }


        // Validar correo electrónico
        if (!/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(correo)) {
            Errorcorreo.textContent = "El correo electrónico no es válido.";
            var Errors = true;
        }


        // Validar edad (número positivo)
        const edadNum = parseInt(edad);
        if (isNaN(edadNum) || edadNum <= 0) {
            Erroredad.textContent = "La edad debe ser un número positivo.";
            var Errors = true;
        }


        // Validar fecha de nacimiento (AAAA-MM-DD)
        if (!/^\d{4}-\d{2}-\d{2}$/.test(fechaNacimiento)) {
            Errorfecha.textContent = "La fecha de nacimiento debe tener el formato AAAA-MM-DD.";
            var Errors = true;
        }
        if(Errors==false){
        // Si todas las validaciones pasaron, puedes enviar el formulario o realizar otras acciones aquí
        NoError.textContent = "Formulario enviado con éxito.";
        }
    });
});
